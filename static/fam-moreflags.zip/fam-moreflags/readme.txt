Created by John Crepezzi
http://seejohncode.com/2009/11/17/fam-fam-fam

As an extension to the original set by Mark James
http://www.famfamfam.com/lab/icons/flags/

Free, use them for anything
